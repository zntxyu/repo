return {
    {
        name = "preamp",
        gain = -4.0,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 1.0,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = 6.0,
    },
    {
        name = "eq",
        frequency = 125.0,
        Q = 1,
        gain = 6.0,
    },
    {
        name = "eq",
        frequency = 250.0,
        Q = 1,
        gain = 2.0,
    },
    {
        name = "eq",
        frequency = 500.0,
        Q = 1,
        gain = -2.0,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = 2.0,
    },
    {
        name = "eq",
        frequency = 2000.0,
        Q = 1,
        gain = 3.0,
    },
    {
        name = "eq",
        frequency = 4000.0,
        Q = 1,
        gain = 1.0,
    },
    {
        name = "eq",
        frequency = 8000.0,
        Q = 1.0,
        gain = -2.0,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 1.0,
        gain = 5.0,
    },
}